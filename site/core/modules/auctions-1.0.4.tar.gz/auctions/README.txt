This adds an Auction node type that embeds an Auction Item inline.
