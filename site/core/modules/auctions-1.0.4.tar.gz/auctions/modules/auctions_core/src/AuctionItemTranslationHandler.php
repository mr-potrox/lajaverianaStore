<?php

namespace Drupal\auctions_core;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for auction_item.
 */
class AuctionItemTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.
}
