<?php

namespace Drupal\auctions_core;

use Drupal\auctions_core\AuctionToolsTrait;

/**
 * Base class to trigger triat
 */
class AuctionToolsBase {

  use AuctionToolsTrait;
}
