<?php

namespace Drupal\auctions_core\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Auction Items entities.
 *
 * @ingroup auctions_core
 */
class AuctionItemDeleteForm extends ContentEntityDeleteForm {


}
