<?php

namespace Drupal\auctions_core\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Auction Bid(s) entities.
 *
 * @ingroup auctions_core
 */
class AuctionBidDeleteForm extends ContentEntityDeleteForm {


}
