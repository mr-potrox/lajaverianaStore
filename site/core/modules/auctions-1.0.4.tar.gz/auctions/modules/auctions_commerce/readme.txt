Important Note:
Your commerce store MUST have a (default) Store setup of addition of Auction Order Item to card will fail. See Watchdog Reports where possible.  This does not alter any existing Commerce setups/configs.

This adds Auction Order Item type.  Triggers from Auction Item 'complete' workflow add new order to winner user.
